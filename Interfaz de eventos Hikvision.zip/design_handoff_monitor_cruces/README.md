# Handoff: Monitor de cruces Hikvision (ANPR)

## Resumen

Interfaz de administración para revisar eventos de cruce de un lector de placas
Hikvision instalado en la caseta de un fraccionamiento privado. Muestra un
listado siempre actualizado (el evento más reciente entra por arriba), un panel
de KPIs con selector de rango de fechas, las tres fotos de los tres canales por
evento en miniatura, un visor flotante con navegación por teclado, y captura
manual de la placa cuando el OCR falla.

Usuario objetivo: **administración, escritorio, muchos filtros.**

## Sobre los archivos de este paquete

Los archivos incluidos son **referencias de diseño hechas en HTML** — un
prototipo que muestra la apariencia y el comportamiento buscados, **no código de
producción para copiar tal cual**. La tarea es **recrear este diseño dentro del
entorno que ya existe en tu proyecto** (React, Vue, Svelte, Blade/Livewire,
Django templates, etc.), usando sus patrones, su router, su capa de datos y sus
librerías, y conectándolo a tu API real. Si el proyecto todavía no tiene un
frontend definido, elige el framework más apropiado e implementa ahí.

El prototipo usa datos simulados generados en el cliente. **Todo ese generador se
descarta**: se sustituye por las llamadas a tu API (ver "Contrato de datos").

## Fidelidad

**Alta fidelidad (hi-fi).** Colores, tipografía, espaciado, estados y micro-copy
son finales. Recrea la UI con precisión usando las librerías del codebase; los
valores exactos están en "Design tokens". Si tu proyecto ya tiene un sistema de
diseño propio, respeta el layout y la jerarquía de este diseño pero usa tus
tokens.

---

## Estructura de la pantalla

Una sola vista, columna vertical, `padding: 16.8px 22.4px 22.4px`, `gap: 16.8px`,
fondo `#161826`. De arriba a abajo:

### 1. Encabezado

- Izquierda: kicker `CONTROL DE ACCESO · HIKVISION ANPR` (10px, `letter-spacing:
  .14em`, uppercase, color `#9184d9`) y título `Cruces de caseta` (Inter 500, 30px).
- Derecha (`margin-left:auto`, 12px, `#9397ab`): punto de 7px `#9184d9` con
  animación `pulse 2s ease-in-out infinite` (opacidad 1 → .2 → 1), texto
  `En vivo`, separador `·`, y `último cruce hace 12 s` (tiempo relativo,
  refrescado cada segundo).

### 2. Barra de filtros

Tarjeta `#232532`, radio 8px, `box-shadow: 0 0 0 1px #3f424d`, `padding: 11.2px`,
`display:flex`, `gap: 11.2px`, `align-items: flex-end`, con wrap.

| Control | Tipo | Ancho | Default |
| --- | --- | --- | --- |
| Desde | `input[type=date]` | 150px | **primer día del mes actual** |
| Hasta | `input[type=date]` | 150px | **último día del mes actual** |
| Placa o casa | `input[type=search]` | 190px | vacío, placeholder `JHT-40 · 1012-03` |
| Dispositivo | `select` | 180px | `Todos` |
| Sentido | segmented | auto | `Todos` / Entradas / Salidas |
| Lectura | segmented | auto | `Todas` / Sin lectura / Baja confianza |
| Limpiar filtros | botón ghost | auto, `margin-left:auto` | — |

El rango de fechas por defecto **siempre** es del día 1 al último día del mes en
curso, calculado en el cliente al montar (no hardcodeado).

Búsqueda: coincidencia por substring, en mayúsculas, contra `placa` **o** `casa`.
"Baja confianza" = evento con placa leída y `confianza < umbral` (umbral
configurable, default **80 %**).

### 3. KPIs

Grid de 4 columnas iguales, `gap: 11.2px`. Cada tarjeta: `#232532`, radio 8px,
`box-shadow: 0 0 0 1px #3f424d`, `padding: 8.4px`. Dentro: kicker 10px uppercase
`letter-spacing:.1em` color `#9184d9`, cifra Inter 500 34px `line-height:1.05`,
pie 11px `rgba(233,233,237,.5)`.

1. **Eventos del periodo** → total filtrado; pie `N entradas · M salidas`.
2. **Placas leídas** → conteo; pie `NN% de lectura efectiva`.
3. **Placas no leídas** → kicker y cifra en rojo `#e0736d`, borde
   `0 0 0 1px #552a27`, y botón ghost rojo 11px `Capturar pendientes →` que
   aplica el filtro `Lectura = Sin lectura`.
4. **Baja confianza** → conteo; pie `bajo 80% de OCR`.

Todos los KPIs se calculan **sobre el conjunto filtrado**, no sobre el total.

### 4. Panel "Último cruce registrado"

Banda con radio 14px y fondo `linear-gradient(100deg, #2b2741, #232532 60%)`,
`padding: 11.2px 16.8px`, flex con wrap.

- Izquierda: kicker `ÚLTIMO CRUCE REGISTRADO` (10px, `#d2cefd`); la **placa en
  monoespaciada 40px**, `letter-spacing:.04em`, color `#e9e9ed` (o `#e0736d` con
  el texto `SIN LECTURA`); fila de meta con chip `Casa 1012-03` (tag accent:
  fondo `#423a6a`, texto `#f5f4ff`, radio 6px, 11px, mono), sentido, hora +
  fecha, tipo y color de vehículo; línea final mono 11px `#75798c` con
  dispositivo y `OCR 93%`.
- Derecha (`margin-left:auto`): las **tres miniaturas de 168×95** con etiqueta
  mono 9px uppercase debajo (`Canal 1 · panorámica`, `Canal 2 · placa`,
  `Canal 3 · conductor`). Clic abre el visor en ese canal.

Este panel se re-renderiza con cada evento nuevo: es el "siempre actualizado".

### 5. Listado de cruces

Tarjeta `#232532` radio 8px, `overflow:hidden`. Cabecera interna: `h5`
`Listado de cruces`, subtítulo 12px `N eventos · 01 ago – 31 ago`, y a la derecha
la pista mono 10px uppercase `↑↓ RECORRER · ENTER ABRIR`.

Contenedor de scroll `max-height: 46vh; overflow: auto`, con `thead` **sticky**
(`position:sticky; top:0; z-index:2; background:#232532`).

Tabla `width:100%; border-collapse:collapse; font-size:14px`. Cabeceras: 11px,
uppercase, `letter-spacing:.08em`, color `rgba(233,233,237,.6)`, padding 5.6px.
Celdas: padding 5.6px.

**Reglas de fila (detalle del sistema):** el separador inferior es un gradiente a
nivel de `<tr>` que se **desvanece a transparente en los últimos 48px de cada
extremo** — no un `border-bottom` completo:
`background: linear-gradient(to right, transparent, rgba(233,233,237,.08) 48px, rgba(233,233,237,.08) calc(100% - 48px), transparent) no-repeat bottom / 100% 1px`.
El hover añade una capa `rgba(233,233,237,.04)` encima sin perder la regla.

Columnas, en orden:

| # | Columna | Ancho | Contenido |
| --- | --- | --- | --- |
| 1 | Fecha / hora | 120px | `HH:MM:SS` mono 13px + línea 10px `#75798c` con `22 ago · hace 4 min` |
| 2 | Casa | 96px | mono 14px, color `#d2cefd` — formato `1012-03` (manzana-lote) |
| 3 | Sentido | 92px | 12px, `↓ entrada` en `#d2cefd` / `↑ salida` en `#b2b6ca` |
| 4 | Placa | 150px | mono 16px `letter-spacing:.03em`; si fue capturada a mano, chip `manual` (tag neutral) a su derecha |
| 5 | OCR | 78px | mono 12px `93%`; `#e0736d` si está bajo el umbral, `#9397ab` si no; `manual` o `—` cuando aplica |
| 6 | Vehículo | 150px | 12px `#b2b6ca`, `SUV gris` |
| 7 | Canales | 200px | tres miniaturas 58×34, radio 4px, `box-shadow: 0 0 0 1px #292b31`, `cursor: zoom-in`, con etiqueta mono 8px `CH1/CH2/CH3` abajo-izquierda |
| 8 | Dispositivo | resto | mono 11px `#75798c` |

**Fila sin lectura:** fondo `color-mix(in srgb, #e0736d 9%, transparent)` y, en la
celda de placa, en lugar del texto, un botón con **borde punteado rojo**
(`1px dashed #e0736d`, texto `#e0736d`, mono 11px, `letter-spacing:.08em`) que
dice `SIN LECTURA`; abre el visor directamente en el **canal 2 (placa)** con el
campo de captura visible.

**Fila seleccionada (teclado):** fondo `color-mix(in srgb, #9184d9 12%, transparent)`;
si además es sin lectura, `color-mix(in srgb, #e0736d 18%, transparent)`.

Estado vacío: `Ningún cruce coincide con estos filtros.` centrado, 13px, `#9397ab`,
padding 22.4px.

### 6. Visor flotante (foto ampliada)

Backdrop `position:fixed; inset:0; display:grid; place-items:center;
background: color-mix(in srgb, #08090f 78%, transparent); z-index:50`. Clic en el
backdrop cierra; clic dentro no propaga.

Panel: `width: min(1080px, 94vw); max-height: 92vh; overflow:auto;` columna con
`gap: 8.4px`, `padding: 11.2px`, radio 14px, fondo `#232532`,
`box-shadow: 0 0 0 1px #9397ab, 0 16px 40px rgba(0,0,0,.65)`.

- **Cabecera:** placa mono 20px (roja + `SIN LECTURA` si aplica), chip
  `Casa 1012-03`, `Entrada · 22 ago 09:41:12`, `OCR 93%` mono, y botón icono 36×36
  `✕` a la derecha.
- **Cuerpo:** botón icono `←` | marco de la foto | botón icono `→`.
  El marco: `flex:1; min-width:0; aspect-ratio:16/9; max-height:56vh;
  margin-inline:auto`, radio 8px. Sobre la foto, barra inferior con gradiente
  `transparent → rgba(8,9,15,.85)`, mono 11px: dispositivo a la izquierda,
  fecha y hora a la derecha.
- **Pie:** filmstrip de tres miniaturas 104×60 (la activa con
  `box-shadow: 0 0 0 2px #9184d9`, las otras `0 0 0 1px #3f424d`), la pista mono
  `← MÁS RECIENTE · → MÁS ANTIGUO · ESC CERRAR`, y a la derecha
  `evento 3 de 64 · foto 2/3`.
- **Panel de captura manual** (solo si la placa no fue leída): fondo `#38201f`,
  borde `0 0 0 1px #552a27`, radio 8px; campo mono uppercase con placeholder
  `ABC-12-34`, botón `Guardar placa` con borde y texto `#e0736d`, y la nota
  `El OCR no leyó esta placa — captúrala desde el canal 2 y queda marcada como manual.`

---

## Interacciones y comportamiento

### Navegación por teclado (la parte crítica)

Se recorre una **secuencia plana** de `evento × 3 fotos`, con el listado ordenado
del más reciente al más antiguo:

```
índice_plano = índice_de_fila * 3 + índice_de_foto
←  →  índice_plano - 1   (hacia lo MÁS RECIENTE)
→  →  índice_plano + 1   (hacia lo MÁS ANTIGUO)
```

Es decir: `→` avanza foto 1 → 2 → 3 y, al llegar al final del evento, **salta al
evento más antiguo** en su foto 1. `←` hace lo inverso y al inicio salta al
evento más reciente en su foto 3. Sin ciclo circular: se detiene en los extremos.

Otros atajos:

- `Esc` cierra el visor (funciona incluso con el foco dentro de un input).
- Con el visor **cerrado**: `↑` / `↓` mueven la fila seleccionada, `Enter` abre el
  visor en el canal 1.
- Cuando el foco está en un `input`, `select` o `textarea`, las flechas **no**
  navegan (solo `Esc` sigue activo).
- `Enter` dentro del campo de captura manual guarda la placa.

### Otros comportamientos

- **Ingesta en vivo:** un evento nuevo se **inserta arriba del listado, sin flash
  ni sonido**. Los KPIs y el panel "Último cruce" se recalculan. En producción
  esto viene de polling o WebSocket (ver abajo).
- Si el visor está abierto cuando llega un evento nuevo, el evento mostrado **no
  cambia**: la posición se resuelve por `id`, no por índice.
- Los tiempos relativos (`hace 12 s`, `hace 4 min`, `hace 2 h`, `hace 3 d`) se
  refrescan con un tick de 1 s.
- Clic en cualquier parte de la fila abre el visor en el canal 1; clic en una
  miniatura abre ese canal (con `stopPropagation`).
- Captura manual: al guardar, se escribe la placa en mayúsculas, el evento deja
  de estar "sin lectura", el chip `manual` aparece en el listado, la columna OCR
  muestra `manual`, y el panel rojo desaparece. **Esto debe hacer PATCH a tu API.**
- Responsive: la barra de filtros y el panel del último cruce hacen wrap. El
  diseño está pensado para escritorio (≥1280px de ancho cómodo).

### Estados de interacción (del sistema de diseño)

- `:focus-visible` → `outline: 2px solid #9184d9; outline-offset: 2px`. Nunca el
  anillo azul del navegador.
- Botón primario = **contorno** de acento sobre transparente, nunca relleno.
  Hover `color-mix(#9184d9 12%, transparent)`, activo `22%`.
- Botón secundario: borde `rgba(233,233,237,.16)`, hover `rgba(233,233,237,.07)`.
- Inputs: fondo `#232532`, borde `rgba(233,233,237,.16)`, `caret-color: #9184d9`,
  hover borde `rgba(233,233,237,.45)`, focus borde `#9184d9`.
- Deshabilitado: `opacity: .45`.
- `::selection`: `color-mix(#9184d9 30%, transparent)`.

---

## Estado necesario

```
eventos: Evento[]            // ordenados desc por timestamp
desde, hasta: string         // 'YYYY-MM-DD', default 1º y último del mes actual
query: string                // busca en placa | casa
dispositivo: string          // 'Todos' | nombre del dispositivo
sentido: 'todos'|'entrada'|'salida'
lectura: 'todas'|'sin'|'baja'
sel: number                  // fila seleccionada por teclado
visorId: string | null       // id del evento abierto (null = cerrado)
visorFoto: 0 | 1 | 2         // canal mostrado
captura: string              // texto del campo de captura manual
umbralConfianza: number      // default 80
```

Derivados (no se guardan): lista filtrada, KPIs, posición plana del visor.

---

## Contrato de datos (lo que hay que conectar a tu API)

El prototipo genera esto en el cliente; sustitúyelo por tus endpoints. Forma
mínima por evento:

```json
{
  "id": "ev1284",
  "timestamp": "2026-08-22T09:41:12-06:00",
  "casa": "1012-03",
  "sentido": "entrada",
  "placa": "JHT-40-92",
  "confianza": 93,
  "manual": false,
  "tipo": "SUV",
  "color": "gris",
  "dispositivo": "Acceso Principal 01",
  "fotos": [
    { "canal": 1, "url": "/media/ev1284_ch1.jpg" },
    { "canal": 2, "url": "/media/ev1284_ch2.jpg" },
    { "canal": 3, "url": "/media/ev1284_ch3.jpg" }
  ]
}
```

- `placa: null` (o cadena vacía) es lo que dispara todo el tratamiento en rojo y
  la captura manual. `confianza: null` cuando no hay lectura.
- `sentido` viene del carril/puerta del Hikvision; si tu payload trae solo el
  nombre del dispositivo, deriva el sentido de él y documenta el mapeo.
- Las tres fotos son los tres canales del evento y **siempre van en el orden
  1 → 2 → 3**; el visor asume que el canal 2 es el recorte de placa (es el que
  se abre para capturar a mano).

Endpoints que la vista necesita:

| Verbo | Ruta sugerida | Uso |
| --- | --- | --- |
| `GET` | `/api/cruces?desde&hasta&q&dispositivo&sentido&lectura&cursor` | listado paginado, orden desc |
| `GET` | `/api/cruces/resumen?desde&hasta&…` | los 4 KPIs calculados en el servidor |
| `GET` | `/api/cruces/stream` (SSE/WS) o polling a `?desde=<último_id>` | eventos nuevos |
| `PATCH` | `/api/cruces/:id/placa` | captura manual → `{ "placa": "ABC-12-34", "manual": true }` |
| `GET` | `/api/dispositivos` | poblar el `select` |

Notas de implementación: el filtrado y los KPIs del prototipo son en memoria —
con volumen real deben ir al servidor. El `max-height: 46vh` del listado quiere
scroll infinito o paginación por cursor. Las miniaturas deben pedir un thumbnail
del servidor, no la imagen completa (58×34 y 168×95 en CSS; sirve 2× para
retina).

---

## Design tokens

Sistema: **Nocturne** — interfaz oscura, compacta, un solo acento usado como
línea y resplandor, nunca como relleno grande. `styles.css` (incluido) es la
fuente de verdad; lee los valores desde sus variables.

**Color**

```
--color-bg        #161826    --color-surface  #232532
--color-text      #e9e9ed    --color-accent   #9184d9
--color-divider   rgba(233,233,237,.16)

neutral 100→900   #f3f5fe #e4e7f5 #cfd3e5 #b2b6ca #9397ab #75798c #595d6c #3f424d #292b31
accent  100→900   #f5f4ff #e7e5fe #d2cefd #b5abfc #968ae0 #796cbf #5d5294 #423a6a #2b2741

alerta (añadida para "sin lectura")
--color-alert     #e0736d    --color-alert-200 #f6d6d2
--color-alert-800 #552a27    --color-alert-900 #38201f
```

En fondo oscuro: pasos 700–900 para rellenos tintados y bordes, 500 como base,
100–300 para texto sobre esos tintes. No usar negro ni blanco puros. No inundar
áreas grandes con el acento.

**Tipografía** — Inter 400/500 (`@import` de Google Fonts en `styles.css`).
Cuerpo 15px / 1.55. `h1` 42 · `h2` 32 · `h3` 25 · `h4` 20 · `h5` 16 · `h6` 13
(uppercase, `.08em`). Títulos peso **500** — no engrosar más;
`line-height: 1.12`, `letter-spacing: -.015em`. Placas, casas, horas,
dispositivos y etiquetas técnicas van en **monoespaciada**
(`ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace`).

**Espaciado** (densidad 0.7×): `2.8 · 5.6 · 8.4 · 11.2 · 16.8 · 22.4 px`.

**Radios**: `sm 4px · md 8px · lg 14px`.

**Sombras**
```
sm  0 0 0 1px #3f424d
md  0 0 0 1px #595d6c, 0 6px 18px rgba(0,0,0,.55)
lg  0 0 0 1px #9397ab, 0 16px 40px rgba(0,0,0,.65)
```
En fondo oscuro la elevación es *un borde de un pixel más oscuridad ambiental* —
no apilar sombras pesadas.

---

## Assets

- **Ninguna imagen real.** Las fotos son marcadores: un rectángulo con
  `repeating-linear-gradient(135deg, #1b1d2b 0 4px, #242636 4px 8px)` y una
  etiqueta monoespaciada. **Sustitúyelos por los `<img>` de tu API.**
- Iconos: el prototipo usa glifos de texto (`←` `→` `✕` `↓` `↑`). El sistema
  recomienda **Phosphor Icons** — si tu proyecto ya lo tiene (o cualquier set
  equivalente), usa `arrow-left`, `arrow-right`, `x`, `arrow-down`, `arrow-up`.
- Fotografías de contenido (si algún día se añaden): el sistema las pasa por
  `.lighten` (`mix-blend-mode: lighten`). **No aplicar a las fotos del ANPR** —
  esas deben verse tal cual.

---

## Archivos de este paquete

- `Monitor de Cruces.dc.html` — el prototipo completo. La primera mitad es la
  plantilla (markup + estilos inline) y la segunda la lógica (generación de datos
  simulados, filtrado, KPIs, navegación por teclado, captura manual). Ábrelo en
  un navegador para ver e interactuar con el diseño.
- `styles.css` — tokens y clases del sistema Nocturne (`.btn`, `.input`, `.card`,
  `.table`, `.tag`, `.seg`, `.field`, `.dialog`). Fuente de verdad de los valores.
- `INSTRUCCIONES-CLAUDE-CODE.md` — cómo usar este paquete con Claude Code en tu
  máquina, con un prompt listo para pegar.
