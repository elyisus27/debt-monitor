# Cómo bajar este diseño a tu proyecto con Claude Code

## 1. Descarga y descomprime

Descarga el zip de este paquete y descomprímelo **dentro** de tu repositorio,
por ejemplo:

```
mi-proyecto/
├── src/ ...            (tu código actual)
├── api/ ...            (tu backend actual)
└── design_handoff_monitor_cruces/
    ├── README.md
    ├── INSTRUCCIONES-CLAUDE-CODE.md
    ├── Monitor de Cruces.dc.html
    └── styles.css
```

Ponerlo dentro del repo es lo importante: así Claude Code puede leerlo con sus
propias herramientas, sin que tengas que pegarle nada.

## 2. Ábrelo en el navegador una vez

```bash
open "design_handoff_monitor_cruces/Monitor de Cruces.dc.html"
```

Interactúa con él (flechas, Esc, clic en las miniaturas, captura manual). Así
sabes exactamente qué le estás pidiendo a Claude Code que reproduzca — y detectas
antes de empezar cualquier cosa que quieras cambiar.

## 3. Lanza Claude Code en la raíz del repo

```bash
cd mi-proyecto
claude
```

## 4. Pega este prompt

> Tengo un paquete de handoff de diseño en `design_handoff_monitor_cruces/`.
>
> 1. Lee `design_handoff_monitor_cruces/README.md` completo, y luego
>    `Monitor de Cruces.dc.html` y `styles.css` de esa misma carpeta.
> 2. Explora mi codebase y dime, **antes de escribir código**: en qué framework y
>    con qué patrones vas a implementar esta vista, en qué rutas/archivos, qué
>    endpoints de mi API ya cubren el contrato de datos del README y cuáles
>    faltan o hay que adaptar. El HTML del paquete es **solo referencia visual**:
>    no lo copies al proyecto, recréalo con mis componentes y convenciones.
> 3. Espera mi confirmación del plan.
> 4. Implementa por partes, en este orden, deteniéndote entre cada una:
>    (a) capa de datos + tipos/modelos contra mi API real;
>    (b) listado con filtros y KPIs;
>    (c) panel de último cruce e ingesta en vivo;
>    (d) visor flotante con la navegación por teclado ←/→ tal como la describe el
>        README (secuencia plana evento × 3 fotos, ← = más reciente);
>    (e) captura manual de placa con su PATCH.
>
> Reglas: respeta los tokens de color, tipografía, espaciado, radios y sombras del
> README al pixel. Si mi proyecto ya tiene un sistema de diseño propio, dímelo y
> propón cómo mapear los tokens antes de decidir. No inventes campos de API: si
> algo del diseño no existe en mi backend, señálalo y propón el endpoint.

## 5. Sobre el "merge" con tu backend

Lo que hace que esto funcione es la sección **"Contrato de datos"** del README:
ahí está la forma del evento (`id`, `timestamp`, `casa`, `sentido`, `placa`,
`confianza`, `manual`, `tipo`, `color`, `dispositivo`, `fotos[3]`) y la tabla de
endpoints que la vista necesita.

Antes de que Claude Code implemente, dale **un ejemplo real de tu payload**:

```bash
curl -s "https://tu-api/…/eventos?limit=1" | tee /tmp/evento-real.json
```

y luego, en la sesión:

> Aquí está un evento real de mi API: `@/tmp/evento-real.json`. Haz el mapeo
> entre estos campos y el contrato del README, y dime qué falta.

Ese mapeo es todo el "merge". Casi siempre lo único que falta del lado del
backend es: **thumbnails** de las tres fotos (para no servir imágenes completas en
el listado), el **endpoint de resumen** para los KPIs, y el **PATCH de placa
manual** con su campo `manual` en la base.

## 6. Si vuelves aquí a iterar el diseño

Pídeme los cambios sobre el prototipo, vuelve a descargar el paquete, reemplaza
la carpeta en tu repo y dile a Claude Code:

> Actualicé `design_handoff_monitor_cruces/`. Haz un diff contra lo que ya
> implementaste y aplica solo lo que cambió.
